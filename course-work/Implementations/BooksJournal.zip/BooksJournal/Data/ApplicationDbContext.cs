﻿using BooksJournal.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace BooksJournal.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser, IdentityRole, string>
    {
        private readonly IConfiguration _config;

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options, IConfiguration config) : base(options)
        {
            _config = config;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(_config.GetConnectionString("DatabaseConnection"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Book>()
                .Property(b => b.Rating)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Read>()
                .Property(r => r.Rating)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<TBR>()
                .Property(t => t.Rating)
                .HasColumnType("decimal(18,2)");
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<Read> Reads { get; set; }
        public DbSet<TBR> TBRs { get; set; }
        public DbSet<Genre> Genres { get; set; }
    }
}
