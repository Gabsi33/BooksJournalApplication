﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace BooksJournal.Models
{
    public class Read
    {
        [Key]
        public int ReadID { get; set; }

        public int BookID { get; set; }
        [ForeignKey("BookID")]
        public virtual Book Book { get; set; }

        public string? Photo { get; set; }

        [Required]
        [StringLength(150, MinimumLength = 2)]
        public string Name { get; set; }

        [Required]
        [StringLength(150, MinimumLength = 2)]
        public string Author { get; set; }

        public int? GenreId { get; set; }
        public virtual Genre? Genre { get; set; }
        public DateTime PublishedDate { get; set; }

        [StringLength(1000, MinimumLength = 2)]
        public string Details { get; set; }

        [Range(0, 5)]
        public decimal? Rating { get; set; }
        public string UserId { get; set; }
        public IdentityUser User { get; set; }
    }
}
