﻿using System.ComponentModel.DataAnnotations;

namespace BooksJournal.Models
{
    public class Book
    {
        [Key]
        public int BookID { get; set; }

        public string? Photo { get; set; }

        [Required]
        [StringLength(150, MinimumLength = 2)]
        public string Name { get; set; }

        [Required]
        [StringLength(150, MinimumLength = 2)]
        public string Author { get; set; }

        public int? GenreId { get; set; }
        public virtual Genre? Genre { get; set; }

        public DateTime PublishedDate { get; set; }

        [StringLength(1000, MinimumLength = 2)]
        public string Details { get; set; }

        [Range(0, 5)]
        public decimal? Rating { get; set; }
  
    }
}
