﻿using System.ComponentModel.DataAnnotations;


namespace BooksJournal.Models
{
    public class Genre
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string Value { get; set; }
        public virtual ICollection<Book>? Books { get; set; }
    }
}
