﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

public class RoleInitializer
{
    public static async Task InitializeAsync(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
    {
        string adminEmail = "ggurova94@gmail.com";
        string password = "Password123!";
        if (await roleManager.FindByNameAsync("admin") == null)
        {
            await roleManager.CreateAsync(new IdentityRole("admin"));
        }
        if (await roleManager.FindByNameAsync("registeredUser") == null)
        {
            await roleManager.CreateAsync(new IdentityRole("registeredUser"));
        }
        if (await userManager.FindByNameAsync(adminEmail) == null)
        {
            IdentityUser admin = new IdentityUser { Email = adminEmail, UserName = adminEmail, EmailConfirmed = true };
            IdentityResult result = await userManager.CreateAsync(admin, password);
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(admin, "admin");
            }
        }
        else
        {
            var admin = await userManager.FindByEmailAsync(adminEmail);
            if (admin != null && !admin.EmailConfirmed)
            {
                admin.EmailConfirmed = true;
                await userManager.UpdateAsync(admin);
            }
        }

    }
}

