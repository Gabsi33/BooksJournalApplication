﻿using BooksJournal.Data;
using BooksJournal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BooksJournal.Controllers
{
    [Authorize(Roles = "admin, registeredUser")]
    public class ReadController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public ReadController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index(string searchString)
        {
            var userId = _userManager.GetUserId(User);
            var readBooksQuery = _context.Reads
                .Include(r => r.Genre)
                .Where(r => r.UserId == userId);

            if (!String.IsNullOrEmpty(searchString))
            {
                searchString = searchString.ToLower();
                readBooksQuery = readBooksQuery.Where(book =>
                    book.Name.ToLower().Contains(searchString) ||
                    book.Author.ToLower().Contains(searchString));
            }

            var readBooks = await readBooksQuery.ToListAsync();
            return View(readBooks);
        }


        [HttpPost]
        [Authorize(Roles = "registeredUser, admin")]
        public async Task<IActionResult> AddToRead(int bookId)
        {
            var userId = _userManager.GetUserId(User);
            var book = await _context.Books.FindAsync(bookId);
            if (book != null)
            {
                var read = new Read
                {
                    BookID = book.BookID,
                    Name = book.Name,
                    Author = book.Author,
                    GenreId = book.GenreId,
                    PublishedDate = book.PublishedDate,
                    Details = book.Details,
                    Rating = book.Rating,
                    Photo = book.Photo,
                    UserId = userId
                };
                _context.Reads.Add(read);
                await _context.SaveChangesAsync();
                return Ok();
            }
            return NotFound();
        }

        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Reads == null)
            {
                return NotFound();
            }

            var read = await _context.Reads.FindAsync(id);
            if (read == null)
            {
                return NotFound();
            }
            ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value", read.GenreId);
            return View(read);
        }

        [Authorize(Roles = "admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookID,Name,Author,GenreId,PublishedDate,Details,Rating")] Read read, IFormFile photo)
        {
            if (id != read.BookID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (photo != null && photo.Length > 0)
                    {
                        var fileName = Path.GetFileName(photo.FileName);
                        var filePath = Path.Combine("wwwroot/pictures", fileName);
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await photo.CopyToAsync(stream);
                        }
                        read.Photo = "/pictures/" + fileName;
                    }
                    else
                    {
                        var existingRead = await _context.Reads.AsNoTracking().FirstOrDefaultAsync(r => r.BookID == id);
                        if (existingRead != null)
                        {
                            read.Photo = existingRead.Photo;
                        }
                    }

                    _context.Update(read);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ReadExists(read.BookID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value", read.GenreId);
            return View(read);
        }

        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Reads == null)
            {
                return NotFound();
            }

            var read = await _context.Reads
                .Include(r => r.Genre)
                .FirstOrDefaultAsync(m => m.BookID == id);
            if (read == null)
            {
                return NotFound();
            }

            return View(read);
        }

        [Authorize(Roles = "admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Reads == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Reads' is null.");
            }
            var read = await _context.Reads.FindAsync(id);
            if (read != null)
            {
                _context.Reads.Remove(read);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReadExists(int id)
        {
            return _context.Reads.Any(e => e.BookID == id);
        }
    }
}
