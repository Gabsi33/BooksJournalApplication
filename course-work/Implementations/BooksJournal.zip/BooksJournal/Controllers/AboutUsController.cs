﻿using Microsoft.AspNetCore.Mvc;

namespace BooksJournal.Controllers
{
    public class AboutUsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
