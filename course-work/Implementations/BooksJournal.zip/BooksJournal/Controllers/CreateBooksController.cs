﻿using BooksJournal.Models;
using BooksJournal.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace BooksJournal.Controllers
{
    [Authorize(Roles = "admin, registeredUser")]
    public class CreateBooksController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        // Default photo path
        private readonly string defaultPhoto = "pictures/BookPhoto.jpg";

        public CreateBooksController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Books
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Books.Include(m => m.Genre);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Books/Create
        [Authorize(Roles = "admin")]
        public IActionResult Create()
        {
            ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value");
            return View();
        }

        // POST: Books/Create
        [Authorize(Roles = "admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookID,Name,Author,GenreId,PublishedDate,Details,Rating")] Book book, IFormFile photo)
        {
            if (ModelState.IsValid)
            {
                if (photo != null && photo.Length > 0)
                {
                    var fileName = Path.GetFileName(photo.FileName);
                    var filePath = Path.Combine("wwwroot/pictures", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await photo.CopyToAsync(stream);
                    }
                    book.Photo = "/pictures/" + fileName;
                }
                else
                {
                    book.Photo = defaultPhoto;
                }

                _context.Add(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value", book.GenreId);
            return View(book);
        }

        [Authorize(Roles = "registeredUser")]
        [HttpPost]
        public async Task<IActionResult> AddToTBR(int bookId)
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            var book = await _context.Books.FindAsync(bookId);
            if (book != null)
            {
                var existingTBR = await _context.TBRs.FirstOrDefaultAsync(t => t.BookID == bookId && t.UserId == userId);
                if (existingTBR != null)
                {
                    return BadRequest("Book already exists in TBR list.");
                }

                var tbr = new TBR
                {
                    BookID = book.BookID,
                    Name = book.Name,
                    Author = book.Author,
                    GenreId = book.GenreId,
                    PublishedDate = book.PublishedDate,
                    Details = book.Details,
                    Rating = book.Rating,
                    Photo = book.Photo,
                    UserId = userId
                };
                _context.TBRs.Add(tbr);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index", "TBR");
            }
            return NotFound();
        }

        [Authorize(Roles = "registeredUser")]
        [HttpPost]
        public async Task<IActionResult> AddToRead(int bookId)
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            var book = await _context.Books.FindAsync(bookId);
            if (book != null)
            {
                var existingRead = await _context.Reads.FirstOrDefaultAsync(r => r.BookID == bookId && r.UserId == userId);
                if (existingRead != null)
                {
                    return BadRequest("Book already exists in Read list.");
                }

                var read = new Read
                {
                    BookID = book.BookID,
                    Name = book.Name,
                    Author = book.Author,
                    GenreId = book.GenreId,
                    PublishedDate = book.PublishedDate,
                    Details = book.Details,
                    Rating = book.Rating,
                    Photo = book.Photo,
                    UserId = userId
                };
                _context.Reads.Add(read);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index", "Read");
            }
            return NotFound();
        }

        [Authorize(Roles = "registeredUser")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MoveToRead(int bookId)
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            // Remove from TBR list
            var tbr = await _context.TBRs.FirstOrDefaultAsync(t => t.BookID == bookId && t.UserId == userId);
            if (tbr != null)
            {
                _context.TBRs.Remove(tbr);
            }

            // Check if the book already exists in the Read list
            var existingRead = await _context.Reads.FirstOrDefaultAsync(r => r.BookID == bookId && r.UserId == userId);
            if (existingRead != null)
            {
                return BadRequest("Book already exists in Read list.");
            }

            // Add to Read list
            var read = new Read
            {
                BookID = tbr.BookID,
                Name = tbr.Name,
                Author = tbr.Author,
                GenreId = tbr.GenreId,
                PublishedDate = tbr.PublishedDate,
                Details = tbr.Details,
                Rating = tbr.Rating,
                Photo = tbr.Photo,
                UserId = userId
            };
            _context.Reads.Add(read);

            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Read");
        }
    }
}
