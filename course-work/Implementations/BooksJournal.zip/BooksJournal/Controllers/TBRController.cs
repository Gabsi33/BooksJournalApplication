﻿using BooksJournal.Data;
using BooksJournal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BooksJournal.Controllers
{
    [Authorize(Roles = "admin, registeredUser")]
    public class TBRController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public TBRController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index(string searchString)
        {
            var userId = _userManager.GetUserId(User);
            var tbrBooksQuery = _context.TBRs
                .Include(t => t.Genre)
                .Where(t => t.UserId == userId);

            if (!String.IsNullOrEmpty(searchString))
            {
                searchString = searchString.ToLower();
                tbrBooksQuery = tbrBooksQuery.Where(book =>
                    book.Name.ToLower().Contains(searchString) ||
                    book.Author.ToLower().Contains(searchString));
            }

            var tbrBooks = await tbrBooksQuery.ToListAsync();
            return View(tbrBooks);
        }


        [HttpPost]
        [Authorize(Roles = "registeredUser, admin")]
        public async Task<IActionResult> AddToTBR(int bookId)
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            var book = await _context.Books.FindAsync(bookId);
            if (book != null)
            {
                var existingTBR = await _context.TBRs.FirstOrDefaultAsync(t => t.BookID == bookId && t.UserId == userId);
                if (existingTBR != null)
                {
                    return BadRequest("Book already exists in TBR list.");
                }

                var tbr = new TBR
                {
                    BookID = book.BookID,
                    Name = book.Name,
                    Author = book.Author,
                    GenreId = book.GenreId,
                    PublishedDate = book.PublishedDate,
                    Details = book.Details,
                    Rating = book.Rating,
                    Photo = book.Photo,
                    UserId = userId
                };
                _context.TBRs.Add(tbr);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index", "TBR");
            }
            return NotFound();
        }

        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.TBRs == null)
            {
                return NotFound();
            }

            var tbr = await _context.TBRs.FindAsync(id);
            if (tbr == null)
            {
                return NotFound();
            }
            ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value", tbr.GenreId);
            return View(tbr);
        }

        [Authorize(Roles = "admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookID,Name,Author,GenreId,PublishedDate,Details,Rating")] TBR tbr, IFormFile photo)
        {
            if (id != tbr.BookID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (photo != null && photo.Length > 0)
                    {
                        var fileName = Path.GetFileName(photo.FileName);
                        var filePath = Path.Combine("wwwroot/pictures", fileName);
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await photo.CopyToAsync(stream);
                        }
                        tbr.Photo = "/pictures/" + fileName;
                    }
                    else
                    {
                        var existingTBR = await _context.TBRs.AsNoTracking().FirstOrDefaultAsync(t => t.BookID == id);
                        if (existingTBR != null)
                        {
                            tbr.Photo = existingTBR.Photo;
                        }
                    }

                    _context.Update(tbr);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TBRExists(tbr.BookID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value", tbr.GenreId);
            return View(tbr);
        }

        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.TBRs == null)
            {
                return NotFound();
            }

            var tbr = await _context.TBRs
                .Include(t => t.Genre)
                .FirstOrDefaultAsync(m => m.BookID == id);
            if (tbr == null)
            {
                return NotFound();
            }

            return View(tbr);
        }

        [Authorize(Roles = "admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.TBRs == null)
            {
                return Problem("Entity set 'ApplicationDbContext.TBRs' is null.");
            }
            var tbr = await _context.TBRs.FindAsync(id);
            if (tbr != null)
            {
                _context.TBRs.Remove(tbr);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TBRExists(int id)
        {
            return _context.TBRs.Any(e => e.BookID == id);
        }

        [Authorize(Roles = "registeredUser")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MoveToRead(int bookId)
        {
            var userId = _userManager.GetUserId(User);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized();
            }

            // Remove from TBR list
            var tbr = await _context.TBRs.FirstOrDefaultAsync(t => t.BookID == bookId && t.UserId == userId);
            if (tbr != null)
            {
                _context.TBRs.Remove(tbr);
            }

            // Check if the book already exists in the Read list
            var existingRead = await _context.Reads.FirstOrDefaultAsync(r => r.BookID == bookId && r.UserId == userId);
            if (existingRead != null)
            {
                return BadRequest("Book already exists in Read list.");
            }

            // Add to Read list
            var read = new Read
            {
                BookID = tbr.BookID,
                Name = tbr.Name,
                Author = tbr.Author,
                GenreId = tbr.GenreId,
                PublishedDate = tbr.PublishedDate,
                Details = tbr.Details,
                Rating = tbr.Rating,
                Photo = tbr.Photo,
                UserId = userId
            };
            _context.Reads.Add(read);

            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Read");
        }
    }
}
