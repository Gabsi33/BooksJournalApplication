﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BooksJournal.Data;
using BooksJournal.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Identity;
using System.IO;
using System.Threading.Tasks;
using System.Security.Claims;

[Authorize(Roles = "admin, registeredUser")]
public class FantasyController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<IdentityUser> _userManager;

    public FantasyController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    [AllowAnonymous]
    public async Task<IActionResult> Index(string searchString, string sortOrder, int? pageNumber)
    {
        var booksQuery = _context.Books
            .Include(b => b.Genre)
            .Where(b => b.Genre.Value == "Fantasy");

        if (!String.IsNullOrEmpty(searchString))
        {
            searchString = searchString.ToLower();
            booksQuery = booksQuery.Where(book =>
                book.Name.ToLower().Contains(searchString) ||
                book.Author.ToLower().Contains(searchString));
        }

        ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
        ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

        switch (sortOrder)
        {
            case "name_desc":
                booksQuery = booksQuery.OrderByDescending(b => b.Name);
                break;
            case "Date":
                booksQuery = booksQuery.OrderBy(b => b.PublishedDate);
                break;
            case "date_desc":
                booksQuery = booksQuery.OrderByDescending(b => b.PublishedDate);
                break;
            default:
                booksQuery = booksQuery.OrderBy(b => b.Name);
                break;
        }

        int pageSize = 8; // 2 rows of 4 books each
        return View(await PaginatedList<Book>.CreateAsync(booksQuery.AsNoTracking(), pageNumber ?? 1, pageSize));
    }



    // Default photo path
    private readonly string defaultPhoto = "C:\\Users\\gguro\\source\\repos\\BooksJournalApplication\\BooksJournal\\wwwroot\\pictures\\BookPhoto.jpg";

    [Authorize(Roles = "admin")]
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null || _context.Books == null)
        {
            return NotFound();
        }

        var book = await _context.Books.FindAsync(id);
        if (book == null)
        {
            return NotFound();
        }
        ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value", book.GenreId);
        return View(book);
    }

    [Authorize(Roles = "admin")]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("BookID,Name,Author,GenreId,PublishedDate,Details,Rating")] Book book, IFormFile photo)
    {
        if (id != book.BookID)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                if (photo != null && photo.Length > 0)
                {
                    var fileName = Path.GetFileName(photo.FileName);
                    var filePath = Path.Combine("wwwroot/pictures", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await photo.CopyToAsync(stream);
                    }
                    book.Photo = "/pictures/" + fileName;
                }
                else
                {
                    var existingBook = await _context.Books.AsNoTracking().FirstOrDefaultAsync(b => b.BookID == id);
                    if (existingBook != null)
                    {
                        book.Photo = existingBook.Photo ?? defaultPhoto;
                    }
                }

                _context.Update(book);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BookExists(book.BookID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        ViewData["GenreId"] = new SelectList(_context.Set<Genre>(), "Id", "Value", book.GenreId);
        return View(book);
    }

    [Authorize(Roles = "admin")]
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null || _context.Books == null)
        {
            return NotFound();
        }

        var book = await _context.Books
            .Include(m => m.Genre)
            .FirstOrDefaultAsync(m => m.BookID == id);
        if (book == null)
        {
            return NotFound();
        }

        return View(book);
    }

    [Authorize(Roles = "admin")]
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        if (_context.Books == null)
        {
            return Problem("Entity set 'ApplicationDbContext.Books' is null.");
        }
        var book = await _context.Books.FindAsync(id);
        if (book != null)
        {
            _context.Books.Remove(book);
        }

        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    private bool BookExists(int id)
    {
        return _context.Books.Any(e => e.BookID == id);
    }

    [Authorize(Roles = "registeredUser")]
    [HttpPost]
    public async Task<IActionResult> AddToTBR(int bookId)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrEmpty(userId))
        {
            return Unauthorized();
        }

        var book = await _context.Books.FindAsync(bookId);
        if (book != null)
        {
            var existingTBR = await _context.TBRs.FirstOrDefaultAsync(t => t.BookID == bookId && t.UserId == userId);
            if (existingTBR != null)
            {
                return BadRequest("Book already exists in TBR list.");
            }

            var tbr = new TBR
            {
                BookID = book.BookID,
                Name = book.Name,
                Author = book.Author,
                GenreId = book.GenreId,
                PublishedDate = book.PublishedDate,
                Details = book.Details,
                Rating = book.Rating,
                Photo = book.Photo,
                UserId = userId
            };
            _context.TBRs.Add(tbr);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "TBR");
        }
        return NotFound();
    }

    [Authorize(Roles = "registeredUser")]
    [HttpPost]
    public async Task<IActionResult> AddToRead(int bookId)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrEmpty(userId))
        {
            return Unauthorized();
        }

        var book = await _context.Books.FindAsync(bookId);
        if (book != null)
        {
            var existingRead = await _context.Reads.FirstOrDefaultAsync(r => r.BookID == bookId && r.UserId == userId);
            if (existingRead != null)
            {
                return BadRequest("Book already exists in Read list.");
            }

            var read = new Read
            {
                BookID = book.BookID,
                Name = book.Name,
                Author = book.Author,
                GenreId = book.GenreId,
                PublishedDate = book.PublishedDate,
                Details = book.Details,
                Rating = book.Rating,
                Photo = book.Photo,
                UserId = userId
            };
            _context.Reads.Add(read);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Read");
        }
        return NotFound();
    }

    [Authorize(Roles = "registeredUser")]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> MoveToRead(int bookId)
    {
        var userId = _userManager.GetUserId(User);
        if (string.IsNullOrEmpty(userId))
        {
            return Unauthorized();
        }

        // Remove from TBR list
        var tbr = await _context.TBRs.FirstOrDefaultAsync(t => t.BookID == bookId && t.UserId == userId);
        if (tbr != null)
        {
            _context.TBRs.Remove(tbr);
        }

        // Check if the book already exists in the Read list
        var existingRead = await _context.Reads.FirstOrDefaultAsync(r => r.BookID == bookId && r.UserId == userId);
        if (existingRead != null)
        {
            return BadRequest("Book already exists in Read list.");
        }

        // Add to Read list
        var read = new Read { BookID = bookId, UserId = userId };
        _context.Reads.Add(read);

        await _context.SaveChangesAsync();
        return RedirectToAction("Index", "Read");
    }

}
