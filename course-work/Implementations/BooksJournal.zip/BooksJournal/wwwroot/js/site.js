﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function searchBooks() {
    var input, filter, bookContainer, books, book, i, txtValue;
    input = document.getElementById('searchBar');
    filter = input.value.toUpperCase();
    bookContainer = document.getElementById('bookContainer');
    books = bookContainer.getElementsByClassName('book-card');

    for (i = 0; i < books.length; i++) {
        book = books[i];
        txtValue = book.textContent || book.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            books[i].style.display = "";
        } else {
            books[i].style.display = "none";
        }
    }
}

function toggleDetails(element) {
    var details = element.previousElementSibling;
    if (details.style.display === "none") {
        details.style.display = "block";
        element.textContent = "See Less";
    } else {
        details.style.display = "none";
        element.textContent = "See More";
    }
}

